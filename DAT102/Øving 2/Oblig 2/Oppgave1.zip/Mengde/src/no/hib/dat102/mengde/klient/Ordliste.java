package no.hib.dat102.mengde.klient;

import no.hib.dat102.mengde.tabell.TabellMengde;
import java.util.*;

public class Ordliste {

    public static void main(String[] args) {
        TabellMengde<String> ordListe1 = new TabellMengde<String>();
        TabellMengde<String> ordListe2 = new TabellMengde<String>();
        TabellMengde<String> unionListe = new TabellMengde<String>();

        String[] ord1 = {"God", "dag", "Hans", "Hansen", "Hansaby", "Olsen", "Ole", "buss", "rute", "Bergen"};
        String[] ord2 = new String[10];
        Scanner tastatur = new Scanner(System.in);

        //Henter ord fra tastatur til ord2
        for (int i = 0; i < 10; i++) {
            System.out.print((i+1) + ": ");
            ord2[i] = tastatur.nextLine();

            //Sjekker om ordet finnes i ordliste 1
            for (String ord : ord1)
                if (ord2[i].equals(ord))
                    System.out.println("Ordet " + ord + " finnes i ordliste 1.");

        }

        //Legger til ord i ordlistene
        for (int i = 0; i < 10; i++) {
            ordListe1.leggTil(ord1[i]);
            ordListe2.leggTil(ord2[i]);
        }

        //Tar Union av listene
        unionListe = (TabellMengde)ordListe1.union(ordListe2);

        Iterator unionOppramser = unionListe.oppramser();
        while (unionOppramser.hasNext()) {
            System.out.println(unionOppramser.next());
        }
    }

}
