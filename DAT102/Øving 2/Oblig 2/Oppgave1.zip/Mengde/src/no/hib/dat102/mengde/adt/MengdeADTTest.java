package no.hib.dat102.mengde.adt;

import no.hib.dat102.mengde.tabell.TabellMengde;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Iterator;

import static org.junit.Assert.*;

public class MengdeADTTest {

    TabellMengde<String> ordListe1;
    TabellMengde<String> ordListe2;

    String[] ord1;
    String[] ord2;

    @Before
    public void setUp() throws Exception {
        ordListe1 = new TabellMengde<String>();
        ordListe2 = new TabellMengde<String>();

        ord1 = new String[] {
                "God", "dag", "Hans", "Hansen", "Hansaby", "Olsen", "Ole", "buss", "rute", "Bergen"
        };

        ord2 = new String[] {
                "God", "dag", "Truls", "Hansen", "Hanne", "Olsen", "Hei", "og", "hå", "Bergen"
        };

        //Legger til ord i ordlistene
        for (int i = 0; i < 10; i++) {
            ordListe1.leggTil(ord1[i]);
            ordListe2.leggTil(ord2[i]);
        }
    }

    @Test
    public void testUnion() throws Exception {
        TabellMengde<String> resultat = new TabellMengde<String>();
        TabellMengde<String> forventet = new TabellMengde<String>();

        String[] forventetOrd = new String[] {
                "God", "dag", "Hans", "Hansen", "Hansaby", "Olsen", "Ole", "buss", "rute", "Bergen",
                "God", "dag", "Truls", "Hansen", "Hanne", "Olsen", "Hei", "og", "hå", "Bergen"
        };

        //Legger til forventede ord
        for (String ord : forventetOrd)
            forventet.leggTil(ord);

        //Bruker union() på ordListe1 og 2 og får reelt resultat
        resultat = (TabellMengde)ordListe2.union(ordListe1);

        assertTrue(resultat.erLik(forventet));
    }

    @Test
    public void testSnitt() throws Exception {
        TabellMengde<String> resultat = new TabellMengde<String>();
        TabellMengde<String> forventet = new TabellMengde<String>();

        String[] forventetOrd = new String[] {
                "God", "dag", "Hansen", "Olsen", "Bergen"
        };

        //Legger til forventede ord
        for (String ord : forventetOrd)
            forventet.leggTil(ord);

        //Bruker union() på ordListe1 og 2 og får reelt resultat
        resultat = (TabellMengde)ordListe2.snitt(ordListe1);

        assertTrue(resultat.erLik(forventet));
    }

    @Test
    public void testDifferans() throws Exception {

    }
}