package Oppgave5.c;

/**
 * Created by Martin on 11.05.2015.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("ab".hashCode());
        System.out.println("123".hashCode());
    }

}
