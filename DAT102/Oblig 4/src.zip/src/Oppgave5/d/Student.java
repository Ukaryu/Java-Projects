package Oppgave5.d;

/**
 * Created by Martin on 11.05.2015.
 */
public class Student {
    int num;
    String name;

    public Student(int num,String name){
        this.num = num;
        this.name = name;
    }
}
